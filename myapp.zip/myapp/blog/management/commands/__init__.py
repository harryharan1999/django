from .populate_posts import Command as PopulatePostsCommand
from .populate_categories import Command as PopulateCategoriesCommand